# CPEP Shift Board — Fictional Demo Only

This is a clickable, mobile-friendly prototype. **No patient information, PHI, or operational clinical data may be entered.** It is not connected to Epic or NYU. Changes are stored only in each device/browser, **not synchronized**.

## Try it on your computer
Double-click `index.html` and open it in Edge, Chrome, or Safari.

## Put the demo behind a shareable link (fictional data only)
1. Create a GitHub account if needed.
2. Create a new repository, such as `cpep-demo`, and set it to **public**. Only fictional sample content belongs here.
3. Upload `index.html` to the repository root and commit it.
4. In repository Settings → Pages, select **Deploy from a branch**, branch `main`, folder `/ (root)`, then Save.
5. Once GitHub displays the Pages address, share that URL. On iPhone, open it in Safari → Share → Add to Home Screen.

**Important:** The URL shares the *app interface*, not shared data. Each person has their own independent demo checklist. A true real-time shared version needs an authenticated backend and database.

## For production use at NYU
Request IT/security/clinical-informatics approval before using real patient data. Production requirements include NYU SSO, role-based access, audit logs, encrypted approved hosting/storage, backup and retention controls, mobile-device management/access review, security assessment, clinical/legal workflow validation, and an approved data flow with Epic. Public GitHub Pages and local browser storage are not appropriate for PHI.
